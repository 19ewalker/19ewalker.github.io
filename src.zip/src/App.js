// App.jsx

import React from 'react';
import logo from './assets/images/ejwlogo.svg';
// Import the BrowserRouter, Route and Link components
import { BrowserRouter, Route, Link } from 'react-router-dom';
import Projects from './components/header/Projects.js';
import Music from './components/header/Music.js';
import About from './components/header/About.js';
import useSticky from "./hooks/useSticky.js"
import Welcome from "./components/header/Welcome"
import Navbar from "./components/header/Navbar"
import './App.css';

function App() {
const { isSticky, element } = useSticky()
return (
    <>
      <Navbar sticky={isSticky} />
      <Welcome element={element} />
    </>
  )
  return (
    <BrowserRouter>
      <div className="App">

        // Set up the Router
        <Route exact path="/" component={Projects} />
        <Route path="/music" component={Music} />
        <Route path="/about" component={About} />

        <div className="navigation">
          <img src={logo} className="logo-image" alt="Logo Image" />
          <div className="navigation-sub">

            // Set up the Links
            <Link to="/" className="item">Projects</Link>
            <Link to="/music" className="item">Music</Link>
            <Link to="/about" className="item">About</Link>

          </div>
        </div>
      </div>
    </BrowserRouter>
  );
}

export default App;
