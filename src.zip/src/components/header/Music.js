import React from "react"

function Music(props) {
  return (
    <div>
      <h1>Music</h1>
    </div>
  )
}

export default Music;
