import React from "react"

import "./Welcome.css"
import Logo from "../../assets/images/ejwlogo.svg"
import About from "./About"
const Welcome = ({ element }) => {
  return (
    <main>
      <section className="welcome">
        <div ref={element}>
          <img src={Logo} alt="logo" className="welcome--logo" />
          <p>
          <font color = "white">Hi there! My name is Elizabeth Joan Walker, and I am interested in tech
          </font>
          </p>
          <button className="welcome__cta-primary">Contact us</button>
        </div>
      </section>
      <About />
    </main>
  )
}

export default Welcome
