import React from "react"

function Projects(props) {
  return (
    <div>
      <h1>Projects</h1>
    </div>
  )
}

export default Projects;
